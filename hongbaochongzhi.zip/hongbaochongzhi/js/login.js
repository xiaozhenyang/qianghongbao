var uid = "";
var userPhone = ""; //获取手机号
var url = "https://y.app.10086.cn/YXMB/JSMiddleware";
var userphone = $(".input1");
var message = $(".input2");
var text = $(".texts");
var regLogin = /^1[34578]\d{9}$/;
var text1 = $(".texts1");
var reg1 = /^\d/;
//点击发送验证码
$(".send").on("click", function() {
	doUserphone();
	if(regLogin.test(userphone.val())) {
		var info = userphone.val();
		settime(this);
		$.ajax({
			type: "post",
			url: url + "/phonevail",
			async: true,
			data: {
				"openid": info,
			},
			success: function(data) {
				console.log(data)
			}
		});
	}
});

//点击登录进行校验
$(".login").on("click", "button", function() {
	var user = doUserphone();
	var pass = doPassword();
	if(user && pass) {
		var info = userphone.val();
		var info1 = message.val();
		var hrefUrl = window.location.href;
		$(".login button").html("验证中..");
		$(".login button").attr("disabled", "disabled");
		$.ajax({
			type: "post",
			url: url + "/ssologinCookie",
			async: true,
			data: {
				"openid": info,
				"password": info1,
				"backUrl" : hrefUrl
			},
			success: function(data) {
				if(data.errcode == "000" || data.errcode == "001" || data.errcode == "002") {
					//						alert("登录失败");
					$(".tishiOne").show();
					$(".tishiText p").html("登录失败！");
					$(".login button").html("登录");
					$(".login button").removeAttr("disabled");
				}
				if(data.errcode == "004") {
					//alert("登录成功");
					//pv和uv统计
					window.location.href = data.url;
//					if(state >= 4 && state <= 6) {
//						$.ajax({
//							type: "post",
//							url: url + "/gamedata/browse",
//							data: {
//								"projectid": proid,
//								"openid": info,
//								"channel": ChannelD
//							},
//							async: true,
//							success: function(data) {
//
//							}
//						});
//					};
//					
//					$(".sign").hide();
//					uid = data.uid;
//					userPhone = info;
//					if(rule) {
//						tiaojian(userPhone, first, veisions);
//					}
					
					//拿到uid在抽奖的时候传给后台
					console.log(data.uid);
				}
			},
			error: function() {
				alert("网络异常，请稍后再试！");
				window.location.reload();
			}

		});

	}
});
//手机号的验证
function doUserphone() {
	text.css("opacity", "1");
	if(userphone.val() == "") {
		text.html("手机号不能为空");
		text.css({
			"line-height": "0.6rem"
		});
		return false;
	} else if(!regLogin.test(userphone.val())) {
		text.html("手机号格式不正确");
		text.css({
			"line-height": "0.6rem"
		})
		return false;
	} else {
		text.css("opacity", "0");
		text.css({
			"line-height": "0.3rem"
		});
		return true;
	}
}
//验证码的验证
function doPassword() {
	text1.css("opacity", "1");
	if(message.val() == "") {
		text1.html("验证码不能为空");
		text1.css({
			"line-height": "0.6rem"
		})
		return false;
	} else if(!reg1.test(message.val())) {
		text1.html("验证码错误 请重新输入！");
		text1.css({
			"line-height": "0.6rem"
		})
		return false;
	} else {
		text1.css("opacity", "0");
		text1.css({
			"line-height": "0.3rem"
		});
		return true;
	}
};

//手机号失去焦点的时候
userphone.on("blur", function() {
	doUserphone();
});
//验证码失去焦点的时候
message.on("blur", function() {
	doPassword();
});

var countdown = 60;

function settime(obj) {
	if(countdown == 0) {
		enterCode = true;
		obj.removeAttribute("disabled");
		obj.value = "发送验证码";
		countdown = 60;
		return;
	} else {
		obj.setAttribute("disabled", true);
		obj.value = "重新发送(" + countdown + ")";
		countdown--;
	}
	setTimeout(function() {
		settime(obj)
	}, 1000)
};