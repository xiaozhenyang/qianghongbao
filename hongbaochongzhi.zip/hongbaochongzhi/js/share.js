function webapp() {
	var sUserAgent = navigator.userAgent.toLowerCase();
	var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
	var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
	var bIsIphone = sUserAgent.match(/iphone/i) == "iphone";
	var bIsMidp = sUserAgent.match(/midp/i) == "midp";
	var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
	var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
	var bIsAndroid = sUserAgent.match(/android/i) == "android";
	var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
	var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
	//document.writeln("您的浏览设备为：");
	if(bIsIpad || bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM || bIsIphone) {
		// document.writeln("phone");手机
		var browser = {
			versions: function() {
				var u = navigator.userAgent;
				return { //移动终端浏览器版本信息
					mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
					android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或uc浏览器
					qq: u.indexOf("MQQBrowser") > -1, //QQ
				};
			}(),
			language: (navigator.browserLanguage || navigator.language).toLowerCase()
		};

		if(browser.versions.mobile) { //判断是否是移动设备打开。browser代码在下面
			var ua = navigator.userAgent.toLowerCase(); //获取判断用的对象
			if(ua.match(/leadeon/i) == "leadeon") {
				return "app";
			}
			if(navigator.userAgent.indexOf('UCBrowser') > -1) {
				return "qita";
			}
			//在微信中打开
			if(ua.match(/MicroMessenger/i) == "micromessenger") {
				return "weixin";
			} else {
				return "qita"
			}

			//                if(browser.versions.qq) {
			//              		return "qq";
			//             		}
			//                //安卓	//UC

		}

	} else {
		return "PC";
	}
};

