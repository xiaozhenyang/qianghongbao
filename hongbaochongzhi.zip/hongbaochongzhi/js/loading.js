//why第一次插件
//xzy第二次更改
//version 1.1
(function($) {
	function PreLoad(list,options,loading) {
		this.list = list;
		this.opts = $.extend({},PreLoad.Defaults,options);
		this.loading=loading;
		this.init();
	}
	PreLoad.Defaults = {
		each: null,
		all: null,
	}
	PreLoad.prototype.progress = function() {
		var opts = this.opts,
			loading=this.loading;
			loadCount++;
			$(loading).text("loading..." + (Math.ceil(loadCount / resCount * 100)) + "%"); //loading...
			$(".logoOrange").css("width",(Math.ceil(loadCount / resCount * 100))+"%");
			if(loadCount >= resCount) {
				$(loading).text("loading...100%"); 
				setTimeout(function() {
					opts.all && opts.all();
				}, 1000);
			}
		},
		PreLoad.prototype.init = function(list,opts) {
			 
			var list = this.list,
				
				_this=this;
				// 资源总量
				resCount = list.length;
			// 当前加载量
			loadCount = 0;
			for(var i = 0; i < list.length; i++) {
				var mate = list[i]; 
				
				if(mate.type == "image") {
					this.loadimg(mate.content, function() {
						_this.progress();
					});
				}else{
					_this.progress();
				}
			}
		},
		PreLoad.prototype.loadimg = function(url, callback) {
			var img = new Image();
			img.src = url;
			img.onload = function() {
				callback && callback();
			};
		};
	$.extend({
		preload: function(list,options,loading) {
			new PreLoad(list,options,loading);
		}
	})

})(jQuery);