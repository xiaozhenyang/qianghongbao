/**
*调用手机客户端
*/
var fashion=
{
	mobile_os:["android", "wp8", "ios"],
	last_cmd:"",
	error_reason:"",
	O2String:function(O)
	{
		var S = [];
		var J = "";
		if (Object.prototype.toString.apply(O) === '[object Array]') {
			for (var i = 0; i < O.length; i++)
				S.push(O2String(O[i]));
			J = '[' + S.join(',') + ']';
		}
		else if (Object.prototype.toString.apply(O) === '[object Date]') {
			J = "new Date(" + O.getTime() + ")";
		}
		else if (Object.prototype.toString.apply(O) === '[object RegExp]' || Object.prototype.toString.apply(O) === '[object Function]') {
			J = O.toString();
		}
		else if (Object.prototype.toString.apply(O) === '[object Object]') {
			for (var i in O) {
				
				var tmp = typeof (O[i]) == 'string' ? '"' + O[i] + '"' : (typeof (O[i]) === 'object' ? O2String(O[i]) : O[i]);
				S.push('"' + i + '"' + ':' + tmp);
			}
			J = '{' + S.join(',') + '}';
		} else if (Object.prototype.toString.apply(O) === '[object Number]') {
			J = O.toString();
		} else if (Object.prototype.toString.apply(O) === '[object String]') {
			J = O ;
		}
		return J;
	},
	mobile_info:{},
	user_call_back:function(obj)
	{
		fashion.error_reason = "undefined user call back.";
	},
	init_cb: function(obj) 
	{
	},
	mobileInvoke:function(jsonstr)
	{
		fashion.last_cmd = "mobileInvoke(" + jsonstr + ")";
//			alert(fashion.last_cmd);
			var obj = eval("("+jsonstr+")");
			if (undefined!=typeof(obj.BUSINESSNAME)  &&"undefined"!=typeof(obj.BUSINESSNAME)  && "initJS"==obj.BUSINESSNAME && undefined!=typeof(obj.OSTYPE)&& "undefined"!=typeof(obj.OSTYPE)) {
				fashion.mobile_info = obj;	
				fashion.init_cb(obj);
			} else {
				fashion.user_call_back(obj);
			}
	},
	set_init_cb:function(func) {
		fashion.init_cb = func;
	},
	/**
	 * 判断操作系统并调用系统的js
	 * @param obj 给手机客户端传递json对象
	 * @param cb 回调js方法
	 */
	invokeMobile:function(obj, cb) {
		var arg = fashion.O2String(obj);
		fashion.last_cmd = "invokeMobile" + arg;
		fashion.user_call_back = cb;
		var u = navigator.userAgent;
		if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1)
		{//android系统
			javascript:sdkInterface.enteryMobile(arg);
		}
		else if(!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/))
		{//ios系统
			//document.location = "mobileFunc:" + arg;
			window.location.href = "mobileFunc:" + arg;
		}
		else if(u.indexOf('IEMobile') > -1)
		{//Windows Phone系统
			window.external.notify(arg);
		}
		else
		{
			fashion.error_reason = "不支持该操作系统";
			return;
		}
	}
};
var mobileInvoke=function(jsonstr) {
	fashion.mobileInvoke(jsonstr);
	};
