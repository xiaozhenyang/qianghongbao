/**
 * js-sdk
 *
 * 错误码只进行大的分类，详细错误通过错误描述字段表述。
 * -1： 系统错误（系统接口错误，内存错误，异常错误）
 * -2： 网络错误（网络接口错误，网络数据错误）
 * -3： 数据错误（非合法数据）
 * -4： 用户取消操作（部分接口用户干预的操作）
 */


(function () {
	var u = navigator.userAgent;
	var android=u.indexOf('Android') > -1;
	//用于对外暴露,init只有在客户端为4.0版本才有
	var leadeon ={
		init:function(){
		},
		voiceRecogResult:function(){

		}
	};
	//各种能力的集合
	var businessNameS=[
		"userStatus",//获取用户登录状态
		"checkSessionIsvalid",//新登录状态接口（会话校验）--V4.0新增
		"getUserInfo",//获取用户基础信息
		"getCallDetail",//获取详单数据
		"qrScan",//直接进入扫一扫功能
		"getContacts",//调用手机通信录
		"sendSMS",//调用系统发短信功能
		"getContactName",//获取通信录联系人姓名
		"newWebview",//打开新页面
		"playSound",//手机振动
		"getNetStatus",//获取网络状态
		"pickPhoto",//调用照相机
		"callPhone",//拨打手机电话
		"goNativePage",//H5调用native功能页面
		"getUserMarketInfo",//查询用户营销活动信息
		"getImei",//获取 IMEI
		"enableShared",//是否显示分享按钮
		"shareMessage",//分享功能
		"payHistory",//查询交费历史
		"getOCR",//扫描充值卡密码(OCR)
		"searchBizHall",//查询实体营业厅
		"nearBizHall",// 附近营业厅
		"encryptString",//加密功能
		"newGuide",//新手引导
		"giveMeScore",//给我评分
		"checkVersion",//版本检测
		"showAuthentication",//调用二次鉴权,说明：用户需要操作敏感用户信息时，需要进行二次鉴权操作
		"getContactAll",//获取通信录信息,说明：获取通信录中所有人的手机号码和姓名
		"setWaterFlowerState",//通知客户端浇花签到状态
		"savePhoto",//保存图片到相册
		"digitalSignature",//网络请求体数字签名
		"showLogin",//调用登录接口
		"getNewPay",//拉起统一支付
		"setTitle",//设置webView标题-V3.8新加
		"assistiveControl",//二级页面情感化插件-V3.8新加
		"showNavBackAndCloseBtn",//导航栏返回及关闭按钮的显示状态-V3.8新加
		"getCatchInfo",//客户端信息采集-V3.8新加
		"closeCurrentWebView",//关闭当前webview-V3.8新加
		"cleanCache",//清除缓存webview-V3.8新加
		"navigationColorSetting",//设置导航栏颜色 -V4.0新增
		"getClientApplicationList",//获得本机所有应用的列表（-V4.0新增，只有安卓有这能力）
		"openApplication", //打开应用（-V4.0新增，只有安卓有这能力）
		"downloadApplication",//调用下载（-V4.0新增）
		"startPlugin",//调起客户端插件（V4.0新增）
		"backToRootView",//用于任意二级页面返回一级页面 -V4.1新增
		"overTime",//会话超时处理接口--V4.0新增,
		"tollSingle",//单点统计 -V4.1新增
		"mainPageUpdate", //首页刷新 -V4.1新增
		"imagesShare", //多图分享 -V4.1新增
		"quitLogin", //注销登录 -V4.1新增
		"voiceRecognizer" //设定是否支持语音识别，在键盘弹出时提供入口 -V4.2新增
	];

	/**
	 * 设置回调成功的函数,并给客户端发送json数据,并构造leadeon结构体
	 * @param {Object} os 前端传递的对象
	 * @param {String} st 业务名称
	 */
	function callNative(os, st){
		if("undefined"===typeof os)
		{
			os={};
		}
		os.businessName=st;
		os.callbackSuccess="callbackSuccess_"+os.businessName;
		os.callbackError="callbackError_"+os.businessName;
		if('undefined'===typeof os.debug)
		{
			os.debug=false;
		}
		if('undefined'===typeof os.success)
		{
			os.success=function(){};

		}
		if('undefined'===typeof os.error)
		{
			os.error=function(){};
		}
		leadeon["callbackChangeSuccess_"+os.businessName]=os.success;
		leadeon["callbackChangeError_"+os.businessName]=os.error;
		leadeon["callbackSuccess_"+os.businessName]=function(dates){
			var jsonstr=dates;
			if (android) { //android系统
				jsonstr=JSON.parse(jsonstr);//安卓不支持传递对象，需要对传递的字符串转换
			}
			leadeon["callbackChangeSuccess_"+os.businessName](jsonstr);
		};
		leadeon["callbackError_"+os.businessName]=function(dates){
			var jsonstr=dates;
			if (android) { //android系统
				jsonstr=JSON.parse(jsonstr);//安卓不支持传递对象，需要对传递的字符串转换
			}
			leadeon["callbackChangeError_"+os.businessName](jsonstr);
		};
		//传值完毕以后就删除多余的属性，没必要给客户端
		delete os.success;
		delete os.error;
		if (android)
		{
			newSdkInterface[os.businessName](JSON.stringify(os));
		}
		else
		{
			newSdkInterface[os.businessName](os);
		}
	}

	businessNameS.forEach(function (businessName) {
		leadeon[businessName]=function(options)
		{
			callNative(options,businessName);
		}
	})

	window.leadeon =leadeon;
})()