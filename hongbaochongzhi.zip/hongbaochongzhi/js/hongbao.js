//显示隐藏公用方法
function sh(a,b){
		$(a).show();
		$(b).hide();
//		$(a).css({
//			"z-Index":"99999"
//		})
}

//活动规则
$(".guize").on("click",function(){
	chama('ActiveRule');
	sh(".rulesone","")
})
$(".close").on("click",function(){
	sh("",".rulesone,.myprizeone,.r-out,.hrefPrize")
})
//我的奖品
$(".jiangpin").on("click",function(){
	chama('MyAward');
	sh(".myprizeone","")
})
//再来一次
$(".onefirst").on("click",function(){
	sh(".first",".index,.r-out");
	$(".prize02").attr("src", " ");
})
//立即领奖
$(".lingjiang").on("click",function(){
	chama('ReceiveAward');
	sh(".first,.myprizeone",".index")
})
//次数已经用完
$(".sure").on("click",function(){
	sh("",".tody,.tem")
})
//关闭领奖地址
$(".add-close").on("click",function(){
	sh(".first",".info,.index")
})
//填写收货地址
$(".address").on("click",function(){
	sh(".info",".r-out")
})
//查看收货地址
$(".look").on("click",function(){
	sh(".perInfo","");
})
//查看收货地址关闭按钮
$(".per-close").on("click",function(){
	sh("",".perInfo")
})
//关闭微信分享
$(".weixinShare").on("click",function(){
	$(this).hide();
})
//登录页关闭按钮
$(".logoOff").on("click",function(){
	sh("",".sign")
})
//通用弹框关闭
$(".tishiSure").on("click","a",function(){
	sh("",".tishiOne")
})





