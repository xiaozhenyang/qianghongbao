function GetQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	//加载后台图片资源
	var r = window.location.search.substr(1).match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}
var proid = GetQueryString("proid");
$("[name='WT.mc_ev']").attr("content", proid);
var iframe = GetQueryString("iframe");
var mode = GetQueryString("mode");
var showKey = GetQueryString("showKey");
var pin = GetQueryString("pin");
var ss = "";
var over = "";
var numAll = "";
var numDay = "";
var numMonth = "";
var state = "";
var id = "";
var sid = "";
var ok = "";
var qudao = "";
var flag = false;
var arr = "";
var a = webapp(); //获取APP
//var userPhone = ""; //获取手机号
var ChannelD = "0";
var ChannelName = "";
var rule = ""; //判定后台是否添加区间段规则
var first = "";
var back = true;
var starttime = "";
var endtime = "";
var conditions = "";
var conditionsarr = "";
var _next = true;
var qianzhi = "";
var veisions = "";
var aa = false;
var dbaa = 0;
var tishi = "";
var zhuan = "";
var user = "";
var spa = "";
var toView = "";
var sureAddress = "";
var shareNull = false;
var shareSure = false;
var shareTitle = "";
var shareContent = "";
var shareImgUrl = "";
var setContent = "";
var shareLastContent = "";
var lock = true; //减少服务器请求
var isPrize = true;
var mateContent = "";
var urls = window.location.href;
var noLogin = false;
var addPrize = "";
var linkRule = ""; //活动规则链接
var linkPrize = ""; //中奖链接
var linkNoPrize = ""; //未中奖链接
var linkMyPrize = ""; //我的奖品链接
var goCheck = "img/goCheck.png";
var goCheck1 = "img/goCheck1.png";
var goCheck2 = "img/goCheck2.png";
var goUse = "img/goUse.png";
var encryptionPhone = "";
var uid = "";
var userPhone = "";
getComeUid();
if(mode != "template") { //启用预览模式
	if(a == "PC" && mode != "preview") {
		if(!iframe) {
			$(".jiazai_a").hide();
		};
	};
	if(showKey) {
		showKeyImg();
	};
	$.ajax({
		type: "post", //采用post请求方式
		url: url + "/project/getProject", //初始化资源接口
		data: {
			"id": proid //向后台传入的参数
		},
		async: false, //同步请求
		success: function(data) { //接口调用成功的回调函数
			//console.log()
			if(data.data == "" || data.data == null) {
				//接口返回的数据为空时，404报错页面会显示出来
				$(".jiazai_a").hide();
				$(".error").show();
				return false;
			};
			state = data.data.status; //上线状态
			qudao = data.data.prochannels; //设置的渠道
			sureAddress = data.data.customtable; //设置领奖信息内容
			//console.log(qudao);
			rule = data.isPricondition; //是否启用前置规则区间段true为启用，反之
			_next = !rule;
			conditions = JSON.parse(data.preType); //设置哪个前置条件
			$(".name").html(data.data.name);
			shareTitle = data.data.sharetitle; //分享标题
			shareContent = data.data.sharecontent; //分享虚拟描述
			shareLastContent = data.data.sharegameendcontent //分享实物描述
			shareImgUrl = data.data.shareimageurl; //分享小图
			addPrize = data.data.shareprizecount; //分享增加奖品
			starttime = data.startTime; //开始时间
			endtime = data.endTime; //结束时间
			$(".eqCode").attr("src", data.data.rcodeurl); //获取二维码
			mateContent = data.data.material;
			mateObj = new Object();
			for(var i = 0; i < mateContent.length; i++) {
				var mate = mateContent[i];
				mateObj[mate.name] = mate.content;
			};
			$(".logoindex").attr("src", mateObj.weifenglogo);
			$(".text pre").text(mateObj.weifengrule);
			//cookie有手机号和uid再次请求前置条件
			if(a != "app") {
				if(userPhone != null && userPhone != "") {
					if(rule) {
						tiaojian(userPhone, first, veisions);
					}
				};
			}
			//loading页百分比加载与接口图片数据关联
			$.preload(mateContent, {
				all: function() {
					console.log(mateContent);
					$.each(mateContent, function(k, v) {
						$("." + mateContent[k].name).attr("src", mateContent[k].content);
						//咪咕券去使用
						if(mateContent[k].name == "goUse") {
							goUse = mateContent[k].content;
						};
						//去查看按钮
						if(mateContent[k].name == "goCheck") {
							goCheck = mateContent[k].content;
						};
						//已使用
						if(mateContent[k].name == "goCheck1") {
							goCheck1 = mateContent[k].content;
						};
						//已过期
						if(mateContent[k].name == "goCheck2") {
							goCheck2 = mateContent[k].content;
						};
						if(mateContent[k].name == "rules") {
							linkRule = mateContent[k].outurl;
						};
						if(mateContent[k].name == "myprize") {
							linkMyPrize = mateContent[k].outurl;
						};
						if(mateContent[k].name == "yihan") {
							linkNoPrize = mateContent[k].outurl;
						};
						if(mateContent[k].name == "zhongjiang") {
							linkPrize = mateContent[k].outurl;
						};

					});
					linkHref();
					$(".jiazai_a").hide();
				}
			}, ".con_a p");
			if(mode != "template" && mode != "preview") {
				setContent = data.data.market; //设置领奖信息注意事项
				//				alert(data.data.market.remark);
				if(state == "" || state == null) {
					$(".error").show();
					return false;
				}
			}
			//活动上线
			if(state >= 4) {
				$(".Prompt").hide(); //活动未开始页面隐藏
			};
			//活动下线
			if(state == 7) {
				$(".offline").show(); //活动线下页面显示
				return false;
			};

		},
		error: function() {
			alert("数据异常，请稍后再试！");
			window.location.reload();
		}
	});
}

//alert(GetQueryString("mode"));
//alert(GetQueryString("appid"));
if(mode == "template") {
	$(".jiazai_a").hide();
	//	$(".share").hide();
}
//以下是由于图片更换接口ajax是同步请求来解决模板不能预览问题
if(qudao != "" && qudao != null) {
	//获取后台的渠道号
	arr = qudao.split(",");
	if(a == "app") {
		ChannelD = 4;
		$("[name='WT.plat']").attr("content", "App"); //app端打开
	}
	if(a == "weixin") {
		$.getScript("js/webtrends.min.js");
		ChannelD = 5;
		$("[name='WT.plat']").attr("content", "WX"); //微信端打开
	}
	if(a == "qita") {
		$.getScript("js/webtrends.min.js");
		ChannelD = 6;
		$("[name='WT.plat']").attr("content", "Touch"); //Touch端打开
		$(".share").hide();
	}
	if(a == "PC") {
		$.getScript("js/webtrends.min.js");
	}
	//防止模板嵌入前台网站后弹出提示框
	if(mode != "template" && mode != "preview") {
		if(iframe) {
			$(".pcStreen").hide();
		} else {
			if(a == "PC") {
				$(".pcStreen").show();
				var iframeUrl = urls + "&iframe=true";
				$("#embedded").attr("src", iframeUrl);

			};
		};
		$.each(arr, function(k, v) {
			ChannelName += arr[k] == 4 ? "【中国移动手机营业厅】" : arr[k] == 5 ? "【微信】 " : arr[k] == 6 ? "【触屏】" : "【移动设备】";
			if(arr[k] == ChannelD) {
				//				alert(arr[k] == ChannelD);
				flag = true;

				return flag;
			};

		});
		if(flag == false) {
			if(a != "PC") {
				//			alert("此活动需通过" + ChannelName + "渠道参与！");
				general("此活动需通过" + ChannelName + "渠道参与！");
			}

		};
		//只设置了移动app渠道进行跳转
		$(".tishiSure").on("click", "a", function() {
			if(arr.length == 1 && arr[0] == 4 && ChannelD != 4) {
				//window.location.href = "http://www.10086.cn/cmccclient/download/?from=singlemessage&isappinstalled=1";
				pullAppDownload(urls);
			};
		});
		//点击去查看在不同终端进行跳转
		$(".result-prize").on("click", ".goCheck,.goCheck1,.goCheck2", function() {
			if(ChannelD == "4") {
				window.location.href = "https://app.10086.cn/leadeon-card/pages/card/myCard.html";
			} else if(ChannelD == "5" || ChannelD == "6") {
				window.location.href = "http://touch.10086.cn/i/mobile/mycoupons.html";
			}
		});

		//咪咕券
		$(".result-prize").on("click", ".goUse", function() {
			if(ChannelD == "4" || ChannelD == "5" || ChannelD == "6") {
				window.location.href = "https://common.open.miguvideo.com?channelId=10310000004&telNo=" + encryptionPhone;
			}

		});
	};

} else {
	$.getScript("js/webtrends.min.js");
};

//判断手机号是否登录
var isLogin = {
	"CODE": 23,
	"BUSINESSNAME": "showlogin"
};
if(ChannelD == "4") {
	fashion.invokeMobile(isLogin, callback_isLogin);
}
//是否登录回调
function callback_isLogin(obj) {
	if(obj.ISLOGIN) {
		leadeon.getUserInfo({
			debug: false,
			success: function(obj) {
				userPhone = obj.phoneNumber;
				veisions = obj.version;
				growBig(userPhone);
				osType = obj.osType;
				clientID = obj.clientID;
				channel = obj.channel;
				$("[name='WT.cid']").attr("content", obj.cid); //客户端唯一标识
				$("[name='WT.mobile']").attr("content", obj.phoneNumber); //手机号
				$("[name='WT.prov']").attr("content", obj.province); //省份编码
				$("[name='WT.city']").attr("content", obj.city); //城市编码
				$("[name='WT.av']").attr("content", 'APP_' + osType + '_' + obj.version); //版本号
				$("[name='WT.clientID']").attr("content", obj.clientID); //client
				$("[name='WT.channel']").attr("content", obj.channel); //channel
				(function() {
					var s = document.createElement("script");
					s.async = true;
					s.src = "js/webtrends.min.js";
					var s2 = document.getElementsByTagName("script")[0];
					s2.parentNode.insertBefore(s, s2);
				}());
				if(rule) {
					zhuan = conditions.preId;
					var preids = "";
					for(var i = 0; i < zhuan.length; i++) {
						if(zhuan[i].id == 1 || zhuan[i].id == 2) {
							//获取用户首次登陆的时间
							dbaa = zhuan[i].id;
							preids = "1";
							break;
						} else {
							preids = "2";
						}
					}
					if(preids == "1") {
						//获取用户首次登陆的时间
						var msg = {
							"CODE": 61,
							"MARKID": "ZS100M",
							"STARTDATE": starttime,
							"ENDDATE": endtime,
							"CELLNUM": userPhone
						}
						fashion.invokeMobile(msg, callback_return);
					} else if(preids == "2") {
						tiaojian(userPhone, first, veisions);
					}
				}
				var demo = {
					// 获取uid
					getUid: function(token) {
						return token.match(/UID=\w+/g)[0].slice(4);
					},
					randomString: function(len) {
						len = len || 32;　　
						var $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';　　
						var maxPos = $chars.length;　　
						var pwd = '';　　
						for(i = 0; i < len; i++) {
							pwd += $chars.charAt(Math.floor(Math.random() * (maxPos + 1)));　　
						}　　
						return pwd;
					}
				};
				if(uid == null || uid == "") {
					if(pin == 1) {

					} else {
						if(!!obj.token) {
							//记录uid
							var appuid = demo.getUid(obj.token);
							TransactionID = demo.randomString(32);
							//登录状态接口（会话校验）
							if(appuid != "" && TransactionID != "" && appuid != null && TransactionID != null) {
								leadeon.checkSessionIsvalid({
									debug: false,
									success: function(res) {
										var status = res.status; //字符串类型，状态：0 校验失败；1 校验成功。
										if(res.status == 1) {
											var urls = "https://y.app.10086.cn/YXMB/osshd/templateKu/href/index.html?pin=1"; //当前页面自己的地址
											var timestamp = new Date().getTime(); //时间戳
											var locHref = "https://login.10086.cn/AppSSO.action?targetChannelID=12023&targetUrl=" + encodeURIComponent(urls) + "&timestamp=" + timestamp + "&UID=" + appuid + "&TransactionID=" + TransactionID;
											setTimeout(function() {
												$(".outside").append('<iframe src="' + locHref + '"  class="hidden"></iframe>');
											}, 1000);
											//								window.location.href = "https://login.10086.cn/AppSSO.action?targetChannelID=12023&targetUrl=" + encodeURIComponent(urls) + "&timestamp=" + timestamp + "&UID=" + appuid + "&TransactionID=" + TransactionID;
										} else {
											//会话失败调用超时接口	,拉起客户端登录
											leadeon.overTime({
												debug: false,
												success: function(res) {},
												error: function(res) {}
											});
										}
									},
									error: function(res) {
										var errNo = res.errCode;
									}
								});
							} else {
								alert("appUid未获取到");
							}

						} else {
							//拉起登录
							leadeon.showLogin();

						}
					}
				};
				//pv和uv统计
				if(state >= 4 && state <= 6) {
					$.ajax({
						type: "post",
						url: url + "/gamedata/browse",
						data: {
							"projectid": proid,
							"openid": userPhone,
							"channel": ChannelD
						},
						async: true,
						success: function(data) {

						}
					});
				}

			},
			error: function(res) {}
		});

	} else {
		noLogin = true;
		(function() {
			var s = document.createElement("script");
			s.async = true;
			s.src = "js/webtrends.min.js";
			var s2 = document.getElementsByTagName("script")[0];
			s2.parentNode.insertBefore(s, s2);
		}());
	}

}
//重新刷新页面
function callback_reload(obj) {
	location.reload();
}

function callback_return(obj) {
	first = obj.FIRSTDATE;
	setTimeout(function() {
		if(obj.ISNEWUSER == 1 || dbaa == 2) {
			tiaojian(userPhone, first, veisions);
		} else {
			user = 1;
		}
	}, 1000)

}
//活动已结束进入预览模式
if(state == 6) {
	$(".over").show();
	$(".Prompt").hide();
	gameover(6);
}

//点击开始游戏
$(".dianji").on("click", function() {
	if(mode == "template") {
		sh(".index", ".first");
		return false;
	}
	if(uid == "") {
		general("动作太快了!");
		return;
	}
	if(qianzhi == 6) {
		sh(".hrefPrize");
		return false;
	}
	if(qianzhi != "") {
		general(tishi);
		return false;
	}
	if(user == 1) {
		general("您不是新用户！");
		return false;
	}
	if(over == 6) {
		general("活动已结束，谢谢参与！");
		return;
	} else if(state >= 4) {
		chama('ReceiveRed');
		if(mode == "preview") {
			general("请扫码参与活动");
			return false;
		}
		if(flag == false) {
			general("此活动只支持" + ChannelName + "渠道参与!");
			return;
		}
		//移动app客户端打开
		if(noLogin) {
			var login = {
				"CODE": 22,
				"BUSINESSNAME": "showlogin"
			};
			fashion.invokeMobile(login, callback_reload);
			return false;
		};
		//微信和touch
		if(ChannelD != 4 && flag == true) {
			if(userPhone == "" || userPhone == null) {
				$(".sign").show();
				return false;
			}
		};
		$.ajax({
			type: "post",
			url: url + "/project/activityBegin",
			data: {
				"ActivityId": proid,
				"UserPhone": userPhone,
				"ChannelD": ChannelD,
				"Uid": uid
			},
			async: true,
			success: function(data) {
				if(data.code == "1001") {
					//后台传过的值
					id = encryption(data.id);
					sid = data.snid;
					$.ajax({
						type: "post",
						url: url + "/project/getPrizeCount",
						async: true,
						data: {
							"ActivityId": proid,
							"UserPhone": userPhone,
							"ChannelD": ChannelD,
							"Uid": uid
						},
						success: function(data) {
							if(data.code == "2001") {
								numAll = data.entireDay; //全程次数
								numDay = data.nowDay; //每日次数
								numMonth = data.monthDay; //每月次数
								if(numAll != null && numAll <= 0) {
									general("您的参与次数已用完,谢谢您的参与！");
									return;
								};
								if(numMonth != null && numMonth <= 0) {
									general("您本月的参与次数已用完,谢谢您的参与！");
									return;
								};
								if(numDay != null && numDay <= 0) {
									general("您今天的参与次数已用完,谢谢您的参与！");
									return;
								};
								sh(".index", ".first");
								return;
							}
							if(data.code == "2002") {
								general("没有此活动！");
								return;
							}
							if(data.code == "2003") {
								sh(".index", ".first");
								return;
							};
							if(data.code == "2005") {
								general("登录超时，请重新登录！");
								$(".sign").show();
								return;
							};
							if(data.code == "2006") {
								general("该渠道不支持此活动！");
								return;
							};
							if(data.code == "1000") {
								$(".sign").show();
							}

						}
					});

				}
				if(data.code == "1002") {
					//					alert("活动未开始")
					general("活动未开始！");
				}
				if(data.code == "1003") {
					//					alert("活动已结束")
					general("活动已结束！");
				}
				if(data.code == "1004") {
					//活动未开始
					nofabu(1004);
				}
				if(data.code == "1005") {
					//手机号为空判断
					//alert("手机号为空,此活动只支持移动APP")
					//					$(".tody_a").show();
				}
				if(data.code == "1006") {
					//					alert("活动ID为空")
					general("活动ID为空！");
				}
				if(data.code == "1007") {
					//					alert("渠道为空")
					general("渠道为空！");
				}
				if(data.code == "1008") {
					//					alert("该地区不能进行此活动")
					general("该地区不能进行此活动！");
				}
				if(data.code == "1009") {
					//					alert("该渠道不支持此活动")
					general("该渠道不支持此活动！");
				}
				if(data.code == "1010") {
					//					alert("系统错误")
					general("系统错误！");
				}
				if(data.code == "1011") {
					//alert("登录超时，请重新登录");
					general("登录超时，请重新登录！");
					$(".sign").show();
				}
				if(data.code == "1000") {
					$(".sign").show();
				}
			}
		});

	} else {
		sh(".index", ".first");
		ss = 1004;
	};
});

//点击红包抽奖
$(".icon_hongbao").on("click", function(event) {
	if(ss == "1004") {
		$(".r-out").show();
		$(".yihan").show();
		return;
	}
	if(mode == "template") {
		$(".r-out").show();
		$(".yihan").show();
	} else if(state >= 4) {
		chama('OpenRed');
		$(".jiazai").show();
		//抽奖
		if(setContent.type == "派奖") {
			//调用派奖接口
			sendPrize();
		} else {
			//抽奖
			next();
		}
	} else {
		$(".r-out").show();
		$(".yihan").show();
	}

})
//我的奖品接口
$(".jiangpin,.lingjiang").on("click", function() {
	var str = "";
	if(mode == "template") {
		$(".null-prize").show();
		return false;
	}
	if(uid == "") {
		general("动作太快了!");
		return;
	}
	if(ss == "1004") {
		$(".null-prize").show()
		return;
	} else if(state >= 4) {
		//移动app客户端打开
		if(noLogin) {
			var login = {
				"CODE": 22,
				"BUSINESSNAME": "showlogin"
			};
			fashion.invokeMobile(login, callback_reload);
		};
		//微信和touch
		if(ChannelD != 4 && flag == true) {
			//	$(".sign").show();
			if(userPhone == "" || userPhone == null) {
				$(".sign").show();
				$(".myprizeone").hide();
				return false;
			}
		}

		if(lock) {
			lock = false;
			myPrize(); //调用我的奖品接口
		} else {
			$(".result-prize").show();
		}

	} else {
		$(".null-prize").show()
	}

});

//我的奖品接口
function myPrize(info) {
	var str = "";
	var cardState = "";
	$.ajax({
		type: "post",
		url: url + "/market/getMyPrizeData",
		data: {
			"projectid": proid,
			"openid": userPhone,
		},
		async: true,
		success: function(data) {
			//console.log(data.data)
			if(data.result == "success") {
				$(data.data).each(function(k, v) {
					//判断奖品里面是否有实物
					if(v.prizename == "PT002") {
						//alert(data.customtableMsg.jsonText);
						if(data.customtableMsg.jsonText == "" || data.customtableMsg.jsonText == undefined) {
							$(".address").show();
							$(".look").hide();
							$(".r-out").hide();
							$(info).show();
							addAddress(sureAddress);
						} else {
							$(".address").hide();
							$(".look").show();
							$(".index").hide();
							$(".first").show();
							$(".myprizeone").show();
							addAddress(sureAddress);
						}
					};
					if(v.prizename == "PT009" || v.prizename == "PT010") { //流量卡劵
						str += '<dl>';
						str += '<dt>';
						str += '<img src="' + v.prizeimageurl + '" class="prize-w "/>';
						str += '</dt>';
						str += '<dd class="line7">';
						if(v.cardStatus == "1") {
							cardState = "去查看 ";
							str += '<p>' + v.awardname + '<img src="' + goCheck + '" class="goCheck" /></p>';
						} else if(v.cardStatus == "2") {
							cardState = "已使用 ";
							str += '<p>' + v.awardname + '<img src="' + goCheck1 + '" class="goCheck1" /></p>';
						} else if(v.cardStatus == "3") {
							cardState = "已过期";
							str += '<p>' + v.awardname + '<img src="' + goCheck2 + '" class="goCheck2" /></p>';
						} else {
							str += '<p>' + v.awardname + '<img src="' + goCheck + '" class="goCheck" /></p>';
						};
						if(v.inserttime != null) {
							str += '<p><span>' + v.inserttime + '</span></p>';
						};
						if(v.failureTime != null) {
							str += '<p>有效期至:<span>' + v.failureTime + '</span></p>';
						}
						str += '</dd>';
						str += '</dl>';
					} else if(v.prizename == "PT011" || v.prizename == "PT012" || v.prizename == "PT013" || v.prizename == "PT014") { //话费卡劵王
						str += '<dl>';
						str += '<dt>';
						str += '<img src="' + v.prizeimageurl + '" class="prize-w "/>';
						str += '</dt>';
						str += '<dd  class="line7">';
						if(v.cardStatus == "1") {
							cardState = "去查看 ";
							str += '<p>' + v.awardname + '<img src="' + goCheck + '" class="goCheck" /></p>';
						} else if(v.cardStatus == "3") {
							cardState = "已使用 ";
							str += '<p>' + v.awardname + '<img src="' + goCheck1 + '" class="goCheck1" /></p>';
						} else if(v.cardStatus == "4") {
							cardState = "已过期";
							str += '<p>' + v.awardname + '<img src="' + goCheck2 + '" class="goCheck2" /></p>';
						} else {
							str += '<p>' + v.awardname + '<img src="' + goCheck + '" class="goCheck" /></p>';
						};
						if(v.inserttime != null) {
							str += '<p><span>' + v.inserttime + '</span></p>';
						};
						if(v.failureTime != null) {
							var failureTime = crtTimeFtt(v.failureTime);
							str += '<p>有效期至:<span>' + failureTime + '</span></p>';
						}
						str += '</dd>';
						str += '</dl>';
					} else if(v.prizename == "PT015") { //咪咕券
						str += '<dl>';
						str += '<dt>';
						str += '<img src="' + v.prizeimageurl + '" class="prize-w "/>';
						str += '</dt>';
						str += '<dd  class="line7">';
						if(v.cardStatus == "1") {
							cardState = "去查看 ";
							str += '<p>' + v.awardname + '<img src="' + goUse + '" class="goUse" /></p>';
						} else if(v.cardStatus == "3") {
							cardState = "已使用 ";
							str += '<p>' + v.awardname + '<img src="' + goCheck1 + '" class="goUse" /></p>';
						} else if(v.cardStatus == "4") {
							cardState = "已过期";
							str += '<p>' + v.awardname + '<img src="' + goCheck2 + '" class="goUse" /></p>';
						} else {
							str += '<p>' + v.awardname + '<img src="' + goUse + '" class="goUse" /></p>';
						};
						if(v.inserttime != null) {
							str += '<p><span>' + v.inserttime + '</span></p>';
						};
						if(v.failureTime != null) {
							var failureTime = crtTimeFtt(v.failureTime);
							str += '<p>有效期至:<span>' + failureTime + '</span></p>';
						}
						str += '</dd>';
						str += '</dl>';
					}else if(v.prizename == "PT016"){//all的券
						str += '<dl>';
						str += '<dt>';
						str += '<img src="' + v.prizeimageurl + '" class="prize-w "/>';
						str += '</dt>';
						str += '<dd  class="line7">';
						str += '<p>' + v.awardname + '<img src="' + goCheck + '" class="goCheck" /></p>';
						if(v.inserttime != null) {
							str += '<p><span>' + v.inserttime + '</span></p>';
						};
						if(v.failureTime != null) {
							var failureTime = v.failureTime;
							var failureTimeYear=failureTime.slice(0,4);
							var failureTimeMonth=failureTime.slice(4,6);
							var failureTimeDay=failureTime.slice(6,8);
							str += '<p>有效期至:<span>' + failureTimeYear+'年' +failureTimeMonth+'月'+failureTimeDay+ '</span></p>';
						}
						str += '</dd>';
						str += '</dl>';
					}else {
						str += "<dl><dt><img src='" + v.prizeimageurl + "' class='prize-w '/></dt><dd  class='line7'><p>" + v.awardname + "</p><p><span>" + v.inserttime + "</span></p></dd></dl>";
					};
				});
				$(".result-prize").html(str);
				$(".result-prize").show();
				$(".null-prize").hide();
			}
			if(data.data == "" || data.data == null) {
				$(".null-prize").show();
				$(".result-prize").hide();
				isPrize = false;
			} else {
				isPrize = true;
			}
		}
	});
};

function crtTimeFtt(time) {
	var reg = "(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})";
	var time1 = time.replace(new RegExp(reg, "gm"), "$1年$2月$3日 ");
	return time1;
};
//实物领奖接口
$(".addaddress").on("click", function() {
	myPrize(".info"); //调用我的奖品接口
})
//活动未发布
function nofabu(b) {
	//	alert("活动未开始，请稍后参与活动！");
	general("活动未开始，请稍后参与活动！");
	ss = b;
	return false;
}
//活动已结束
function gameover(c) {
	over = c;
}

//手机号加密
function growBig(id) {
	if(a == "app") {
		var msg = {
			"CODE": 63,
			"BUSINESSNAME": "encryptString",
			"str": id
		};
		fashion.invokeMobile(msg, growReturn);
	}
}

function growReturn(obj) {
	encryptionPhone = obj.encryptString;
}
//加锁
function encryption(id) {
	if(a == "app") {
		var msg = {
			"CODE": 63,
			"BUSINESSNAME": "encryptString",
			"str": id
		};
		fashion.invokeMobile(msg, passWord);
	}

}

function passWord(obj) {
	ok = obj.encryptString;
}
//请求抽奖接口
function next() {
	$.ajax({
		type: "post",
		url: url + "/market/drawRulePrize",
		data: {
			"projectid": proid,
			"openid": userPhone,
			"mode": "常规",
			"channel": ChannelD,
			"Uid": uid
		},
		async: true,
		beforeSend: function() {
			$(".jiazai").show()
		},
		success: function(data) {
			console.log(data);
			//未中奖
			if(data.data == "" || data.data == null) {
				$(".jiazai").hide();
				$(".r-out").show();
				$(".yihan").show();
				$(".r-prize").hide();
				$(".nozhongjiang").html(data.notprize);
				shareNull = true;
			} else {
				//判断奖品是实物还是虚拟
				if(data.data.customTableList == "" || data.data.customTableList == null) {
					$(".jiazai").hide();
					$(".lingjiang").show();
					$(".addaddress").hide();
					$(".r-out").show();
					$(".r-prize").show();
					$(".yihan").hide();
					$(".prize02").attr("src", data.data.prizeimageurl);
					$(".liuliang span").html(data.data.winningtips);
					shareSure = true;
					lock = true;
				} else {
					var str = "";
					spa = data.data.customTableList;
					$(".jiazai").hide();
					$(".lingjiang").hide();
					$(".addaddress").show();
					$(".r-out").show();
					$(".r-prize").show();
					$(".yihan").hide();
					$(".prize02").attr("src", data.data.prizeimageurl);
					$(".liuliang span").html(data.data.winningtips);
					shareSure = true;
					lock = true;
					//					$.each(data.data.customTableList, function(k, v) {
					//						str += "<p><label><span>" + data.data.customTableList[k].keytext + "</span><input type='text' id=" + data.data.customTableList[k].keytext + " name=" + data.data.customTableList[k].keytext + " /></label></p>"
					//					});
					addAddress(spa);
					//$(".information").html(str);

				}

			}
		},
		complete: function() {
			$(".jiazai").hide()
		},
		error: function() {
			alert("数据异常，请稍后再试！");
			$(".jiazai").hide();
			$(".r-out").hide();
			$(".index").hide();
			$(".first").show();
		}
	});
}

//派奖接口
function sendPrize() {
	$.ajax({
		type: "post",
		url: url + "/market/drawFlowPrize",
		data: {
			"projectid": proid,
			"openid": userPhone,
			"mode": "派奖",
			"vail": ok,
			"channel": ChannelD,
			"Uid": uid,
			"snid": sid,
			"answernum": "0"
		},
		async: true,
		beforeSend: function() {
			$(".jiazai").show()
		},
		success: function(data) {
			console.log(data);
			//未中奖
			if(data.data == "" || data.data == null) {
				$(".jiazai").hide();
				$(".r-out").show();
				$(".yihan").show();
				$(".r-prize").hide();
				$(".nozhongjiang").html(data.notprize);
				shareNull = true;
			} else {
				//判断奖品是实物还是虚拟
				if(data.data.customTableList == "" || data.data.customTableList == null) {
					sh(".first,.myprizeone", ".index");
				} else {
					var str = "";
					spa = data.data.customTableList;
					sh(".first,.myprizeone", ".index");
					//					$.each(data.data.customTableList, function(k, v) {
					//						str += "<p><label><span>" + data.data.customTableList[k].keytext + "</span><input type='text' id=" + data.data.customTableList[k].keytext + " name=" + data.data.customTableList[k].keytext + " /></label></p>"
					//					});
					addAddress(spa);
					//$(".information").html(str);

				};
				myPrize(); //调用我的奖品接口
				shareSure = true;
				lock = true;

			}
		},
		complete: function() {
			$(".jiazai").hide()
		},
		error: function() {
			alert("数据异常，请稍后再试！");
			$(".jiazai").hide();
			$(".r-out").hide();
			$(".index").hide();
			$(".first").show();
		}
	});
}

function addAddress(Address) {
	var str = "";
	$.each(Address, function(k, v) {
		str += "<p><label><span>" + Address[k].keytext + "</span><input type='text' id=" + Address[k].keytext + " name=" + Address[k].keytext + " /></label></p>"
	});
	$(".information").html(str);
	$(".hint").text(setContent.remark);
}

//前置条件
function tiaojian(userPhone, first, veisions) {
	_next = false;
	aa = false;
	//充值条件判断
	requestPre(userPhone, first, veisions);
	//	});
}
//前置条件接口请求
function requestPre(userPhone, first, veisions) {
	$.ajax({
		type: "post",
		url: url + "/preConditionAction/preCondition",
		data: {
			"ActivityId": proid,
			"UserPhone": userPhone,
			"FirstDate": first,
			"Versions": veisions
		},
		async: false,
		success: function(data) {
			back = data.flag;
			_next = back;
			if(data.flag == false) {
				if(data.message != "") {
					qianzhi = 6;
					tishi = data.returnMsg;
					return false;
				}else {
					qianzhi = data.preType;
					tishi = data.returnMsg;
					return false;
				}
			}
		},
		error: function() {
			general("网络异常!")

		}
	});

}
//收货地址信息正则验证
var userTel;
var userEmail;
var userCard;
var reg = /^1[34578]\d{9}$/;
var regEamil = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
var regCard = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;
//地址
function vailAddress(vailContent) {
	if(vailContent == "电话") {
		userTel = $('#电话').val();
		if(!reg.test(userTel)) {
			//			alert("手机号格式不正确!");
			general("手机号格式不正确！");
			return false;
		}
		return true;
	}
	if(vailContent == "电子邮箱") {
		userEmail = $("#电子邮箱").val();
		if(!regEamil.test(userEmail)) {
			//			alert("邮箱格式不正确!");
			general("邮箱格式不正确！");
			return false;
		}
		return true;
	}
	if(vailContent == "身份证") {
		userCard = $("#身份证").val();
		if(!regCard.test(userCard)) {
			//			alert("身份证格式不正确!");
			general("身份证格式不正确！");
			return false;
		}
	}
	return true;
};

function jointContent() {
	var sequence = "";
	var flagContent = false;
	for(var i = 0, bb = sureAddress.length; i < sureAddress.length; i++) {
		if($("#" + sureAddress[i].keytext).val() == "") {
			//			alert(sureAddress[i].keytext + "不能为空！");
			general(sureAddress[i].keytext + "不能为空！");
			return false;
		};
		var jmd = vailAddress(sureAddress[i].keytext);
		if(!jmd) {
			break;
		};
		if(i == bb - 1) {
			sequence += sureAddress[i].keytext + ":" + $("#" + sureAddress[i].keytext).val();
			flagContent = true;
		} else {
			sequence += sureAddress[i].keytext + ":" + $("#" + sureAddress[i].keytext).val() + ",";
		};
	};
	if(flagContent) {
		return sequence;
	} else {
		return false;
	};

}
//收货信息按钮提交
$(".sub").on("click", function() {
	var vailjoint = jointContent();
	if(vailjoint == false) {
		return false;
	};
	$.ajax({
		type: "post",
		url: url + "/market/insertCustomTable",
		data: {
			"projectid": proid,
			"openid": userPhone,
			"values_string": vailjoint
		},
		async: true,
		beforeSend: function() {
			$(".ceng").show();
		},
		success: function(data) {
			if(data.flag) {
				//				alert(data.message)
				general(data.message);
			} else {
				//				alert(data.message)
				general(data.message);
			}
		},
		complete: function() {
			$(".ceng").hide();
			$(".info").hide();
			$(".index").hide();
			$(".first").show();
			$(".look").show();
			$(".address").hide();
		},
		error: function() {
			alert("数据异常，请稍后再试！");
			$(".ceng").hide();
			$(".info").hide();
			$(".index").hide();
			$(".first").show();
		}
	});
})

//查看收货地址
$(".look").on("click", function() {
	$.ajax({
		type: "post",
		url: url + "/gameProjectCustomtableAction/viewCustomMsg",
		data: {
			"ActivityId": proid,
			"UserPhone": userPhone,
		},
		async: true,
		success: function(data) {
			var aa = data.jsonText.split(",");
			var str = "";
			$.each(aa, function(k, v) {
				str += "<p>" + v + "</p>";
			});
			$(".perSure").html(str);
		}
	});

});

//分享
$(".share").on("click", function() {
	chama('Share');
	var str = "";
	var activityPath = window.location.href;
	var msg = {
		"CODE": 24,
		"BUSINESSNAME": "shareMsg",
		"CONTENT": shareContent,
		"TITLE": shareTitle,
		"IMAGE": shareImgUrl,
		"URL": activityPath
	};
	var msg1 = {
		"CODE": 24,
		"BUSINESSNAME": "shareMsg",
		"CONTENT": shareLastContent,
		"TITLE": shareTitle,
		"IMAGE": shareImgUrl,
		"URL": activityPath
	};

	$.ajax({
		type: "post",
		url: url + "/gamedata/share",
		data: {
			"ActivityId": proid,
			"UserPhone": userPhone,
			"channel": ChannelD,
		},
		async: true,
		success: function(data) {

			if(ChannelD == 4 && shareSure) {
				fashion.invokeMobile(msg1);
			} else if(ChannelD == 4 && shareNull) {
				fashion.invokeMobile(msg);
			} else if(ChannelD == 5) {
				$(".weixinShare").show();
			} else {
				if(lock) {
					lock = false;
					$.ajax({
						type: "post",
						url: url + "/market/getMyPrizeData",
						data: {
							"projectid": proid,
							"openid": userPhone,
						},
						async: true,
						success: function(data) {
							//console.log(data.data)
							if(data.result == "success") {
								$(data.data).each(function(k, v) {
									//判断奖品里面是否有实物
									if(v.prizename == "PT002") {
										//alert(data.customtableMsg.jsonText);
										if(data.customtableMsg.jsonText == "" || data.customtableMsg.jsonText == undefined) {
											$(".address").show();
											$(".look").hide();
											$(".r-out").hide();
											addAddress(sureAddress);
										} else {
											$(".address").hide();
											$(".look").show();
											$(".index").hide();
											$(".first").show();
											$(".myprizeone").show();
											addAddress(sureAddress);
										}
									};
									//console.log(v.prizeimageurl);
									str += "<dl><dt><img src='" + v.prizeimageurl + "' class='prize-w df575489-8458-4798-9d4c-eb63eeadd54eYS'/></dt><dd><p>" + v.awardname + "</p><p><span>" + v.inserttime + "</span></p></dd></dl>"
								});
								$(".result-prize").html(str);
								$(".result-prize").show();
								$(".null-prize").hide();
							};
							if(data.data == "" || data.data == null) {
								$(".null-prize").show();
								$(".result-prize").hide();
								isPrize = false;
							} else {
								isPrize = true;
							}
						}
					});
				};
				if(isPrize) {
					fashion.invokeMobile(msg1);
				} else {
					fashion.invokeMobile(msg);
				}

			};
			if(addPrize) {
				lock = true;
			} else {
				lock = false;
			};

		}
	});

});

//拉起客户端后能够直接到达活动页面
function pullAppDownload(urls) {
	var u = navigator.userAgent;
	if(u.indexOf('Android') > -1 || u.indexOf('Linux') > -1) {
		if(undefined == urls || "" == urls) {
			location.href = 'com.greenpoint://android.mc10086.activity';
		} else {
			location.href = 'com.greenpoint://android.mc10086.activity?url=' + urls;
		}
	} else if(!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
		if(undefined == urls || "" == urls) {
			location.href = 'cn.10086.app://';
		} else {
			location.href = 'cn.10086.app://' + urls;
		}
	}
	setTimeout(function() {
		location.href = 'http://www.10086.cn/cmccclient/download';

	}, 250);
	setTimeout(function() {
		location.reload();
	}, 1000);
};

//通用弹框
function general(bounced) {
	$(".tishiOne").show();
	$(".tishiText p").html(bounced);
};
//cookie
function getCookie(name) {
	var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
	if(arr = document.cookie.match(reg))
		return unescape(arr[2]);
	else
		return null;
};

function setCookie(name, value) {
	var Days = 30;
	var exp = new Date();
	exp.setTime(exp.getTime() + 30 * 60 * 1000);
	document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString() + ";path=/";
}

function delCookie(name) {
	var exp = new Date();
	exp.setTime(exp.getTime() - 1);
	var cval = getCookie(name);
	if(cval != null)
		document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString() + ";path=/";
}

$(".delCook").on("click", function() {
	//	setCookie("uid","");
	//	setCookie("openid","");
	delCookie("uid");
	delCookie("uid")
	alert("退出成功!")
});
/**
 *平台点击图片显示对应图 
 */
function showKeyImg() {
	if($("." + showKey).length > 1) {
		$("." + showKey).eq(0).parents().show();
		$("." + showKey).eq(0).show();
		$("." + showKey).eq(0).addClass("shanDong");
		if($("." + showKey).hasClass("yihan")) {
			$("." + showKey).eq(0).removeClass("shanDong");
			$("." + showKey).eq(1).addClass("shanDong");
		}
	} else {
		$("." + showKey).parents().show();
		$("." + showKey).show();
		$("." + showKey).addClass("shanDong");
	}

};

function linkHref() {
	if(linkRule != "" && linkRule != null) {
		$(".text").css("height", "6.2rem");
		var arr = linkRule.split(";");
		var html = '<a href="' + arr[1] + '" style="position: absolute;bottom: 5%;left:0;width: 100%;text-align: center;text-decoration: underline;color: blue;font-size: 0.3rem;">' + arr[0] + '</a>';
		$(".rulestwo").append(html);
	};
	if(linkMyPrize != "" && linkMyPrize != null) {
		var arr = linkMyPrize.split(";");
		var html = '<a href="' + arr[1] + '" style="position: absolute;bottom: 5%;left:0;width: 100%;text-align: center;text-decoration: underline;color: blue;font-size: 0.3rem;">' + arr[0] + '</a>';
		$(".myprizetwo").append(html);
	};
	if(linkPrize != "" && linkPrize != null) {
		var arr = linkPrize.split(";");
		var html = '<a href="' + arr[1] + '" style="position: absolute;bottom: 15%;left:0;width: 100%;text-align: center;text-decoration: underline;color: blue;font-size: 0.3rem;">' + arr[0] + '</a>';
		$(".r-prize").append(html);
	};
	if(linkNoPrize != "" && linkNoPrize != null) {
		var arr = linkNoPrize.split(";");
		var html = '<a href="' + arr[1] + '" style="position: absolute;bottom: 15%;left:0;width: 100%;text-align: center;text-decoration: underline;color: blue;font-size: 0.3rem;">' + arr[0] + '</a>';
		$(".yihan").append(html);
	};
};

//click事件插码
function chama(ma) {
	Webtrends.multiTrack({
		argsa: ['DCS.dcsuri', '/nopv.gif', 'WT.event', ma]
	});
};

function getComeUid() {
	uid = getCookie("uid");
	userPhone = getCookie("openid");
}

function getComeUid2(uid2, userPhone2) {
	uid = uid2;
	userPhone = userPhone2;
	setCookie("uid", uid2);
	setCookie("openid", userPhone2);
}